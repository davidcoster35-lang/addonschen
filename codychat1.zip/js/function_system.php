<script>
var system = <?php echo jsonSystemMessage(); ?>
</script>