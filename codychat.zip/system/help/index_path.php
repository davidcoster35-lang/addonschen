<p class="help_title">Index path<p>
<p class="help_text">
The index path must be an absolute path of your chat location and must not end with a /
</p>
<p class="help_tlink">Example</p>
<a class="help_link" href="#">https://yoururl.com/chat</a>