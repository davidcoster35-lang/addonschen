<p class="help_title">Email filter<p>
<p class="help_text">
The email filter is a restrictive filter. It only allows email addresses specified in the
filter to register in the system. When activated, this feature improves security by
not allowing temporary emails that are not listed to enter the system.
</p>