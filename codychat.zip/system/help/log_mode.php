<p class="help_title">Log style<p>
<p class="help_text">
Changing this setting will reset all colors from all members in the system to avoid collision between bubbles and other logs style colors.
</p>