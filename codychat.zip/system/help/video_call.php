<p class="help_title">Video call<p>
<p class="help_text">
Before using call feature make sure you fill api 
credential for the selected provider in the api tab.
</p>