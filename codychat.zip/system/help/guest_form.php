<p class="help_title">Extended guest form<p>
<p class="help_text">
Guest extended form will require Guest visitor to provide their
age and gender instead of only asking for a desired username.
</p>