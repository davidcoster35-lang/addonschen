<p class="help_title">Flood tolerance<p>
<p class="help_text">
This setting is used to limit the number of messages a single user
can send to the system in a 10-second interval before the system
sees it as a flood attempt.
</p>