<p class="help_title">Bridge system<p>
<p class="help_text">
This option can be activated when using the chat inside a CMS such as Wordpress, Wowonder, or
other available CMS bridges. This option will convert the current login page to allow users
logged in the CMS to access the chat without the need of filling out a registration form.
</p>