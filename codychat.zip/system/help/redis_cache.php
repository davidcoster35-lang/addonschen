<p class="help_title">Redis cache<p>
<p class="help_text">
Redis is a server-side in-memory database that can improve server load on
higher chat traffic. To use Redis, you'll need to install the Redis
server and PHP Redis extension.
</p>