<p class="help_title">Rate limit<p>
<p class="help_text">
When activated, this option monitors how many requests are sent by a single user 
in a 20-second interval. Once that limit is reached, the system will completely 
ignore future requests sent by the user for 5 minutes.
</p>