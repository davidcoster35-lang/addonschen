<p class="help_title">Openai<p>
<p class="help_text">
The AI moderation system require the use of an external resource and 
require an API key to be activated. You can easely create your API 
key by following the link below.
</p>
<p class="help_tlink">Openai</p>
<a target="_BLANK" class="help_link" href="https://openai.com/chatgpt/pricing">https://openai.com/chatgpt/pricing</a>