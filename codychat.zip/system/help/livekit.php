<p class="help_title">Livekit<p>
<p class="help_text">
The video and audio call system uses an external resource and
requires an API key to be activated. You can easily create your 
API key by following the link below.
</p>
<p class="help_tlink">Livekit</p>
<a target="_BLANK" class="help_link" href="https://livekit.io">https://livekit.io</a>