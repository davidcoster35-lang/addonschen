<p class="help_title">Agora<p>
<p class="help_text">
The video and audio call system uses an external resource and requires 
an API key to be activated. You can easily create your API key by following 
the link below.
</p>
<p class="help_tlink">Agora</p>
<a target="_BLANK" class="help_link" href="https://agora.io">https://agora.io</a>