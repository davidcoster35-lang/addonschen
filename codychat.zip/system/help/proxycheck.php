<p class="help_title">Proxycheck<p>
<p class="help_text">
Limit access to your site by blocking VPNs from entering your chat. This option requires an API key.
</p>
<p class="help_tlink">Proxycheck</p>
<a target="_BLANK" class="help_link" href="https://proxycheck.io/">https://proxycheck.io/</a>