<p class="help_title">Coppa compliance<p>
<p class="help_text">
By activating COPPA compliance, you ensure that visitors under the age of 13
are restricted from entering the site or registering, in accordance with the
Children's Online Privacy Protection Act (COPPA).
</p>
<p class="help_tlink">Learn more</p>
<a target="_BLANK" class="help_link" href="https://ftc.gov/legal-library/browse/rules/childrens-online-privacy-protection-rule-coppa">https://ftc.gov/legal-library/browse/rules/childrens-online-privacy-protection-rule-coppa</a>