<p class="help_title">Gifts<p>
<p class="help_text">
The gift system allows users to buy and send gifts to other 
members using gold or ruby. This system requires the wallet 
system to be activated.
</p>