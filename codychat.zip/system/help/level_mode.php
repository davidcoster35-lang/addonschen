<p class="help_title">Level mode<p>
<p class="help_text">
The coefficient are the difficulty of each level. The higher the
coefficient is higher is the xp required to complete each levels.
</p>