<p class="help_title">Captcha<p>
<p class="help_text">
Improve your protection from automated bot actions by adding a 
captcha verification to crucial system parts such as registration 
and guest login.
</p>
<p class="help_tlink">Google recaptcha</p>
<a target="_BLANK" class="help_link" href="https://google.com/recaptcha/about/">https://google.com/recaptcha/about/</a>
<p class="help_tlink">Cloudflare turnstile</p>
<a target="_BLANK" class="help_link" href="https://cloudflare.com/products/turnstile/">https://cloudflare.com/products/turnstile/</a>
<p class="help_tlink">Hcaptcha</p>
<a target="_BLANK" class="help_link" href="https://hcaptcha.com/">https://hcaptcha.com/</a>