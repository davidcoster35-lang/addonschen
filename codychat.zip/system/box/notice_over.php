<div class="modal_content">
	<div class="centered_element tpad25">
		<div class="bpad3">
			<img class="med_icon" src="default_images/icons/warning.svg"/>
		</div>
		<div class="bpad15 tpad10">
			<p class="tpad5"><?php echo $boom; ?></p>
		</div>
	</div>
</div>
<div class="modal_control centered_element">
	<button type="button" class="reg_button theme_btn close_over"><?php echo $lang['close']; ?></button>
</div>