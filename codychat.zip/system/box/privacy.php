<?php
require('../config.php');
?>
<div class="modal_content">
	<div class="text_box">
		<?php echo loadPageData('privacy_policy'); ?>
	</div>
</div>