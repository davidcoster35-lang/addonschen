<?php
require('../config.php');
?>
<div class="modal_content">
	<div class="centered_element tpad25">
		<div class="bpad15 tpad10">
			<p class="text_med bold"><?php echo $lang['sorry']; ?></p>
			<p class="tpad5"><?php echo $lang['coppa_text']; ?></p>
		</div>
	</div>
</div>
<div class="modal_control centered_element">
	<button class="close_modal reg_button ok_btn"><?php echo $lang['ok']; ?></button>
</div>