<div data="" onclick="quoteLog(this);" class="submenu_item bhover logmm log_quote">
	<?php echo subMenu('reply', $lang['quote'], $lang['quote_text']); ?>
</div>
<div data="" onclick="hideLog(this);" class="submenu_item bhover logmm log_hide">
	<?php echo subMenu('eye-slash', $lang['hide'], $lang['hide_text']); ?>
</div>
<div data="" onclick="deleteLog(this);" class="submenu_item bhover logmm log_delete">
	<?php echo subMenu('trash-can', $lang['delete'], $lang['delete_text']); ?>
</div>
<div data="" onclick="reportChatLog(this);" class="submenu_item bhover logmm log_report">
	<?php echo subMenu('exclamation-circle', $lang['report'], $lang['report_text']); ?>
</div>