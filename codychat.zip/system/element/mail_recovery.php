<div>
<?php echo str_replace('%user%', $boom['username'], $lang['dear_user']); ?>
</div>
<br/>
<div>
<?php echo $lang['recovery_message']; ?>
</div>
<br/>
<div>
<?php echo $boom['data']; ?>
</div>
<br/>
<div>
<?php echo $lang['kind_regard']; ?>
<br/>
<?php echo $setting['title']; ?>
</div>