<div data="<?php echo $boom['load']; ?>" class="get_dat bpmenu page_menu_item">
	<div class="page_menu_icon">
		<i class="fa fa-<?php echo $boom['icon']; ?> menup"></i>
	</div>
	<div class="page_menu_text">
		<?php echo $boom['txt']; ?>
	</div>
	<div class="page_menu_notify">
		<div id="<?php echo $boom['id']; ?>" class="fnotify bnotify"></div>
	</div>
</div>