<div>
<?php echo $boom['content']; ?>
</div>
<br/>
<div>
----------------------------------------------------------------
</div>
<br/>
<div>
<?php echo $boom['content2']; ?>
</div>
<br/>