<div class="btable">
	<div class="bcell_mid top_notify_avatar">
		<img src="<?php echo myAvatar($boom['user_tumb']); ?>"/>
	</div>
	<div class="bcell_mid hpad5">
		<div class="username bold">
			<?php echo $boom['user_name']; ?>
		</div>
		<div class="">
			<?php echo $boom['content']; ?>
		</div>
	</div>
</div>