<div class="cost_tag_wrapper <?php echo $boom['class']; ?>">
	<div class="btable_auto fborder cost_tag">
		<div class="bcell_mid cost_tag_icon">
			<img src="<?php echo $boom['icon']; ?>"/>
		</div>
		<div class="bcell_mid hpad3">
			<?php echo $boom['amount']; ?> <?php echo $boom['text']; ?>
		</div>
	</div>
</div>