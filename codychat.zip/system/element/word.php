<div class="sub_list_item blisting">
	<div class="sub_list_name">
		<?php echo $boom['word']; ?>
	</div>
	<div onclick="deleteWord(this, <?php echo $boom['id']; ?>);" class="sub_list_option delete_word">
		<i class="fa fa-times"></i>
	</div>
</div>