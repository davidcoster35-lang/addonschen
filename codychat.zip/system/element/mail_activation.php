<div>
<?php echo str_replace('%user%', $boom['username'], $lang['dear_user']); ?>
</div>
<br/>
<div>
<?php echo $lang['activation_message']; ?>
</div>
<br/>
<div>
<?php echo str_replace('%data%', $boom['data'], $lang['activation_code']); ?>
</div>
<br/>
<div>
<?php echo $lang['kind_regard']; ?>
<br/>
<?php echo $setting['title']; ?>
</div>
