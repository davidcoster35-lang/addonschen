<div class="sub_list_item update_item btauto blisting">
	<div class="sub_list_content hpad5">
		Codychat <?php echo $boom; ?>
	</div>
	<div class="sub_list_cell bcauto">
		<button class="default_btn reg_button work_button"><i class="fa fa-clock-o"></i> Updating ...</button>
		<button data="<?php echo $boom; ?>" type="button" class="theme_btn reg_button update_system"><i class="fa fa-upload edit_btn"></i> <?php echo $lang['install']; ?></button>
	</div>
</div>