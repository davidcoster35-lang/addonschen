<div class="boom_notice btable fborder">
	<div class="boom_notice_icon bcell_mid">
		<img src="default_images/system/<?php echo $boom['type']; ?>.svg"/>
	</div>
	<div class="boom_notice_spacer bcell">
	</div>
	<div class="boom_notice_text bcell_mid">
		<?php echo $boom['text']; ?>
	</div>
</div>