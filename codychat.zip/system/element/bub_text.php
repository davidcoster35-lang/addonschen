<p class="bubtext">
	<?php echo $boom; ?>
</p> 