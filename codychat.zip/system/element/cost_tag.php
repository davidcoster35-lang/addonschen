<div class="cost_tag_wrapper <?php echo $boom['class']; ?>">
	<div class="btable_auto fborder cost_tag">
		<div class="bcell_mid cost_tag_icon">
			<img src="<?php echo $boom['icon']; ?>"/>
		</div>
		<div class="bcell_mid cost_tag_amount">
			<?php echo $boom['amount']; ?>
		</div>
	</div>
</div>