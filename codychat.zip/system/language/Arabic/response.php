<?php
$elang['invalid_command'] = "هذا الأمر غير موجود";
$elang['email_exist'] = "يوجد حساب بالفعل بهذا البريد الإلكتروني";
$elang['error'] = "حدث خطأ";
$elang['updated'] = "تم التحديث بنجاح";
$elang['cannot_user'] = "لا يمكنك تنفيذ هذا الإجراء على المستخدم المحدد";
$elang['confirmed_command'] = "تم تنفيذ الأمر بنجاح";
$elang['bad_login'] = "اسم المستخدم أو كلمة المرور غير صحيحة";
$elang['invalid_username'] = "اسم المستخدم المُحدد غير صالح";
$elang['username_exist'] = "اسم المستخدم المُحدد موجود بالفعل";
$elang['invalid_email'] = "البريد الإلكتروني المُحدد غير صالح";
$elang['sel_age'] = "يرجى اختيار عمرك";
$elang['access_requirement'] = "أنت لا تستوفي متطلبات الدخول إلى هذه الغرفة";
$elang['wrong_pass'] = "كلمة المرور خاطئة";
$elang['room_full'] = "هذه الغرفة ممتلئة، جرب غرفة أخرى";
$elang['friend_sent'] = "تم إرسال طلب الصداقة الخاص بك";
$elang['new_friend'] = "تهانينا، لقد حصلت على صديق جديد";
$elang['empty_field'] = "يرجى ملء جميع الحقول";
$elang['room_name'] = "اسم الغرفة غير صالح";
$elang['room_description'] = "وصف الغرفة قصير جداً";
$elang['invalid_pass'] = "يجب أن تكون كلمة المرور بين 6 و 24 حرفاً";
$elang['room_exist'] = "اسم الغرفة المحدد موجود بالفعل";
$elang['max_room'] = "لقد وصلت إلى الحد الأقصى لعدد الغرف لديك";
$elang['wrong_file'] = "نوع الملف المُحدد غير مسموح به";
$elang['no_file'] = "يجب أن تختار ملفاً";
$elang['file_big'] = "ملفك كبير جداً";
$elang['too_short'] = "معيار البحث قصير جداً";
$elang['clean_complete'] = "تم التنظيف";
$elang['cant_modify_user'] = "ليس لديك إذن لتعديل هذا المستخدم";
$elang['saved'] = "تم الحفظ";
$elang['action_complete'] = "تم الإجراء";
$elang['email_sent'] = "تم إرسال البريد الإلكتروني، يرجى التحقق من بريدك";
$elang['room_block'] = "حالياً لا يمكنك دخول الغرفة المحددة";
$elang['bad_actual'] = "كلمة المرور القديمة غير صحيحة";
$elang['not_match'] = "كلمتا المرور الجديدتان غير متطابقتين";
$elang['recovery_sent'] = "تم إرسال كلمة مرور مؤقتة إلى بريدك الإلكتروني";
$elang['no_user'] = "لم يُعثر على مستخدم بالبيانات المدخلة";
$elang['something_wrong'] = "تم اكتشاف شيء غير مألوف، يرجى الانتظار ليقوم المسؤول بمراجعة حسابك";
$elang['max_reg'] = "لقد وصلت إلى الحد الأقصى المسموح به من التسجيلات حالياً، يرجى المحاولة لاحقاً";
$elang['select_something'] = "يرجى اختيار شيء";
$elang['reported'] = "شكراً لتبليغك";
$elang['already_erase'] = "المنشور لم يعد موجوداً";
$elang['already_reported'] = "هذا المنشور تم التبليغ عنه مسبقاً";
$elang['ignored'] = "تم إضافة المستخدم إلى قائمة تجاهلك";
$elang['cannot_contact'] = "حالياً لا يمكنك الاتصال بهذا المستخدم";
$elang['new_message'] = "رسالة جديدة";
$elang['data_exist'] = "البيانات التي أدخلتها موجودة بالفعل";
$elang['register_close'] = "حالياً لا نقبل طلبات تسجيل جديدة، يرجى المحاولة لاحقاً";
$elang['site_connect'] = "يرجى الاتصال بالموقع للدخول إلى الدردشة";
$elang['no_bridge'] = "لم يتم اكتشاف جسر في الموقع المحدد";
$elang['invalid_code'] = "الرمز غير صحيح";
$elang['already_action'] = "تم تنفيذ هذا الإجراء مسبقاً";
$elang['missing_recaptcha'] = "يرجى إكمال الـ reCAPTCHA";
$elang['no_result'] = "لم يتم العثور على نتائج";
$elang['restricted_content'] = "هناك شيء غير مسموح به في البيانات المُرسَلة، يرجى تعديله";
$elang['report_limit'] = "لقد وصلت إلى حد البلاغات الخاص بك";
$elang['vpn_usage'] = "يرجى إيقاف تشغيل VPN/وكيلك للدخول إلى الموقع";
$elang['coppa'] = "لا يمكنك دخول الموقع في هذا الوقت";
$elang['age_requirement'] = "لا تستوفي متطلبات عمر الموقع";
$elang['no_gold'] = "ليس لديك ما يكفي من الذهب لإكمال هذه المعاملة";
$elang['invalid_data'] = "بيانات غير صالحة";
$elang['call_fail'] = "العضو غير متاح في الوقت الحالي.";
$elang['low_balance'] = "رصيدك غير كافٍ.";
$elang['invalid_amount'] = "مبلغ غير صالح";
$elang['file_blocked'] = "الملف لا يتوافق مع إرشاداتنا";
$elang['call_block'] = "عذراً، لا يمكنك دخول هذه المكالمة";
$elang['act_limit'] = "يرجى الانتظار لاستخدام هذه الميزة مجدداً";
$elang['max_attempt'] = 'عدد كبير جداً من المحاولات الفاشلة';
$elang['cannot_action'] = 'لا يمكنك تنفيذ هذا الإجراء';

/* system message */ 

$slang['system__join'] = "انضم %user% إلى الغرفة";
$slang['system__clear'] = "تم مسح هذه الغرفة بواسطة %user%";
$slang['system__name'] = "أصبح %custom% معروفاً الآن باسم %user%";
$slang['system__kick'] = "تم طرد %user%";
$slang['system__ban'] = "تم حظر %user%";
$slang['system__mute'] = "تم كتم %user%";
$slang['system__block'] = "تم حظر %user% من الغرفة";

/* top notification */

$plang['user_join'] = "متصل";
?>