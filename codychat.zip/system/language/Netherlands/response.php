<?php
$elang['invalid_command'] = "Die opdracht bestaat niet";
$elang['email_exist'] = "Er bestaat al een account met dat e-mail adres";
$elang['error'] = "Er is een fout opgetreden";
$elang['updated'] = "Update voltooid";
$elang['cannot_user'] = "Je kunt deze actie niet uitvoeren op de opgegeven gebruiker";
$elang['confirmed_command'] = "Opdracht succesvol afgerond";
$elang['bad_login'] = "Onjuiste gebruikersnaam of wachtwoord";
$elang['invalid_username'] = "De gekozen gebruikersnaam is ongeldig";
$elang['username_exist'] = "De gekozen gebruikersnaam bestaat al";
$elang['invalid_email'] = "Het gekozen e-mail adres is ongeldig";
$elang['sel_age'] = "Selecteer alstublieft uw leeftijd";
$elang['access_requirement'] = "Je voldoet niet aan de toegangseisen voor deze kamer";
$elang['wrong_pass'] = "Wachtwoord onjuist";
$elang['room_full'] = "Deze kamer is vol, probeer alstublieft een andere";
$elang['friend_sent'] = "Je vriendschapsverzoek is verzonden";
$elang['new_friend'] = "Gefeliciteerd, je hebt net een nieuwe vriend gemaakt";
$elang['empty_field'] = "Vul alstublieft alle velden in";
$elang['room_name'] = "Ongeldige kamernaam";
$elang['room_description'] = "Beschrijving van de kamer is te kort";
$elang['invalid_pass'] = "Wachtwoord moet tussen 6 en 24 tekens zijn";
$elang['room_exist'] = "De gekozen kamernaam bestaat al";
$elang['max_room'] = "Je hebt je maximaal aantal kamers al bereikt";
$elang['wrong_file'] = "Het gekozen bestandstype is niet toegestaan";
$elang['no_file'] = "Je moet een bestand selecteren";
$elang['file_big'] = "Je bestand is te groot";
$elang['too_short'] = "Zoekcriteria zijn te kort";
$elang['clean_complete'] = "Schoonmaak voltooid";
$elang['cant_modify_user'] = "Je hebt geen rechten om deze gebruiker te bewerken";
$elang['saved'] = "Opgeslagen";
$elang['action_complete'] = "Actie voltooid";
$elang['email_sent'] = "E-mail verstuurd, controleer uw inbox";
$elang['room_block'] = "Je kunt momenteel niet de geselecteerde kamer betreden";
$elang['bad_actual'] = "Het oude wachtwoord is onjuist";
$elang['not_match'] = "De nieuwe wachtwoorden komen niet overeen";
$elang['recovery_sent'] = "Een tijdelijk wachtwoord is naar je e-mail gestuurd";
$elang['no_user'] = "Er is geen gebruiker gevonden met deze gegevens";
$elang['something_wrong'] = "Er is iets ongewoons gedetecteerd, wacht alstublieft tot een beheerder je account controleert";
$elang['max_reg'] = "Je hebt het maximaal aantal toegestane registraties bereikt, probeer het later opnieuw";
$elang['select_something'] = "Selecteer alstublieft iets";
$elang['reported'] = "Bedankt voor je melding";
$elang['already_erase'] = "De post bestaat niet meer";
$elang['already_reported'] = "Deze post is al gemeld";
$elang['ignored'] = "Gebruiker toegevoegd aan je negeerlijst";
$elang['cannot_contact'] = "Je kunt deze gebruiker momenteel niet contacteren";
$elang['new_message'] = "Nieuw bericht";
$elang['data_exist'] = "De door jou ingevoerde gegevens bestaan al";
$elang['register_close'] = "We accepteren momenteel geen nieuwe registraties, probeer later opnieuw";
$elang['site_connect'] = "Maak verbinding met de site om de chat te betreden";
$elang['no_bridge'] = "Geen brug gedetecteerd op de opgegeven locatie";
$elang['invalid_code'] = "Verkeerde code";
$elang['already_action'] = "Deze actie is al ingesteld";
$elang['missing_recaptcha'] = "Vul alstublieft de reCAPTCHA in";
$elang['no_result'] = "Geen resultaten gevonden";
$elang['restricted_content'] = "Er is iets in de verzonden gegevens dat niet is toegestaan, bewerk het alstublieft";
$elang['report_limit'] = "Je hebt je meldlimiet bereikt";
$elang['vpn_usage'] = "Schakel alstublieft je VPN/proxy uit om toegang tot de site te krijgen";
$elang['coppa'] = "Je kunt momenteel niet op de site komen";
$elang['age_requirement'] = "Je voldoet niet aan de leeftijdsvereisten van de site";
$elang['no_gold'] = "Je hebt niet genoeg goud om deze transactie uit te voeren";
$elang['invalid_data'] = "Ongeldige gegevens";
$elang['call_fail'] = "Het lid is momenteel niet beschikbaar.";
$elang['low_balance'] = "Onvoldoende saldo.";
$elang['invalid_amount'] = "Ongeldig bedrag";
$elang['file_blocked'] = "Het bestand komt niet overeen met onze richtlijnen";
$elang['call_block'] = "Sorry, je kunt niet deelnemen aan dit gesprek";
$elang['act_limit'] = "Wacht alstublieft totdat u deze functie opnieuw kunt gebruiken";
$elang['max_attempt'] = 'Te veel mislukte pogingen';
$elang['cannot_action'] = 'Je kunt deze actie niet uitvoeren';

/* system message */ 

$slang['system__join'] = "%user% is de kamer binnengekomen";
$slang['system__clear'] = "Deze kamer is gewist door %user%";
$slang['system__name'] = "%custom% heet nu %user%";
$slang['system__kick'] = "%user% is gekickt";
$slang['system__ban'] = "%user% is verbannen";
$slang['system__mute'] = "%user% is gedempt";
$slang['system__block'] = "%user% is in de kamer geblokkeerd";

/* top notification */

$plang['user_join'] = "Is verbonden";
?>