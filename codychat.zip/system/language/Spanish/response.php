<?php
$elang['invalid_command'] = "Ese comando no existe";
$elang['email_exist'] = "Ya existe una cuenta con ese correo electrónico";
$elang['error'] = "Ha ocurrido un error";
$elang['updated'] = "Actualización completada";
$elang['cannot_user'] = "No puedes realizar esta acción sobre el usuario especificado";
$elang['confirmed_command'] = "Comando ejecutado correctamente";
$elang['bad_login'] = "Nombre de usuario o contraseña incorrectos";
$elang['invalid_username'] = "El nombre de usuario seleccionado no es válido";
$elang['username_exist'] = "El nombre de usuario seleccionado ya existe";
$elang['invalid_email'] = "El correo electrónico seleccionado no es válido";
$elang['sel_age'] = "Por favor selecciona tu edad";
$elang['access_requirement'] = "No cumples los requisitos para acceder a esta sala";
$elang['wrong_pass'] = "Contraseña incorrecta";
$elang['room_full'] = "Esta sala está llena, por favor prueba con otra";
$elang['friend_sent'] = "Tu solicitud de amistad ha sido enviada";
$elang['new_friend'] = "¡Felicidades, acabas de hacer un nuevo amigo!";
$elang['empty_field'] = "Por favor rellena todos los campos";
$elang['room_name'] = "Nombre de sala no válido";
$elang['room_description'] = "La descripción de la sala es demasiado corta";
$elang['invalid_pass'] = "La contraseña debe tener entre 6 y 24 caracteres";
$elang['room_exist'] = "El nombre de sala seleccionado ya existe";
$elang['max_room'] = "Ya has alcanzado tu número máximo de salas";
$elang['wrong_file'] = "El tipo de archivo seleccionado no está permitido";
$elang['no_file'] = "Debes seleccionar un archivo";
$elang['file_big'] = "Tu archivo es demasiado grande";
$elang['too_short'] = "Los criterios de búsqueda son demasiado cortos";
$elang['clean_complete'] = "Limpieza completada";
$elang['cant_modify_user'] = "No tienes permiso para editar este usuario";
$elang['saved'] = "Guardado";
$elang['action_complete'] = "Acción completada";
$elang['email_sent'] = "Correo enviado, por favor revisa tu email";
$elang['room_block'] = "Actualmente no puedes entrar en la sala seleccionada";
$elang['bad_actual'] = "La contraseña antigua es incorrecta";
$elang['not_match'] = "Las nuevas contraseñas no coinciden";
$elang['recovery_sent'] = "Se ha enviado una contraseña temporal a tu correo";
$elang['no_user'] = "No se encontró ningún usuario con esos datos";
$elang['something_wrong'] = "Se detectó algo inusual, espera a que un administrador revise tu cuenta";
$elang['max_reg'] = "Has alcanzado el número máximo de registros permitidos por ahora, por favor vuelve a intentarlo más tarde";
$elang['select_something'] = "Por favor selecciona algo";
$elang['reported'] = "Gracias por reportarlo";
$elang['already_erase'] = "La publicación ya no existe";
$elang['already_reported'] = "Esta publicación ya ha sido reportada";
$elang['ignored'] = "Usuario añadido a tu lista de ignorados";
$elang['cannot_contact'] = "Actualmente no puedes contactar a este usuario";
$elang['new_message'] = "Nuevo mensaje";
$elang['data_exist'] = "Los datos que ingresaste ya existen";
$elang['register_close'] = "Actualmente no estamos aceptando nuevos registros, por favor vuelve a intentarlo más tarde";
$elang['site_connect'] = "Por favor conéctate al sitio para entrar al chat";
$elang['no_bridge'] = "No se detectó puente en la ubicación especificada";
$elang['invalid_code'] = "Código incorrecto";
$elang['already_action'] = "Esta acción ya ha sido establecida";
$elang['missing_recaptcha'] = "Por favor completa el reCAPTCHA";
$elang['no_result'] = "No se han encontrado resultados";
$elang['restricted_content'] = "Algo en los datos enviados no está permitido, por favor edítalo";
$elang['report_limit'] = "Has alcanzado tu límite de reportes";
$elang['vpn_usage'] = "Por favor desactiva tu VPN/proxy para entrar al sitio";
$elang['coppa'] = "No puedes entrar al sitio en este momento";
$elang['age_requirement'] = "No cumples los requisitos de edad del sitio";
$elang['no_gold'] = "No tienes suficiente oro para completar esta transacción";
$elang['invalid_data'] = "Datos inválidos";
$elang['call_fail'] = "El miembro no está disponible en este momento.";
$elang['low_balance'] = "Saldo insuficiente.";
$elang['invalid_amount'] = "Cantidad inválida";
$elang['file_blocked'] = "El archivo no cumple con nuestras directrices";
$elang['call_block'] = "Lo siento, no puedes entrar en esta llamada";
$elang['act_limit'] = "Por favor espera para usar esa función de nuevo";
$elang['max_attempt'] = 'Demasiados intentos fallidos';
$elang['cannot_action'] = 'No puedes realizar esta acción';

/* system message */ 

$slang['system__join'] = "%user% se ha unido a la sala";
$slang['system__clear'] = "Esta sala ha sido limpiada por %user%";
$slang['system__name'] = "%custom% ahora se llama %user%";
$slang['system__kick'] = "%user% ha sido expulsado";
$slang['system__ban'] = "%user% ha sido bloqueado";
$slang['system__mute'] = "%user% ha sido silenciado";
$slang['system__block'] = "%user% ha sido bloqueado en la sala";

/* top notification */

$plang['user_join'] = "Está conectado";
?>