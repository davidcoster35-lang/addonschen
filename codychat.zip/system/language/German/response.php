<?php
$elang['invalid_command'] = "Dieser Befehl existiert nicht";
$elang['email_exist'] = "Ein Konto mit dieser E-Mail existiert bereits";
$elang['error'] = "Ein Fehler ist aufgetreten";
$elang['updated'] = "Aktualisierung abgeschlossen";
$elang['cannot_user'] = "Du kannst diese Aktion für den angegebenen Benutzer nicht durchführen";
$elang['confirmed_command'] = "Befehl erfolgreich ausgeführt";
$elang['bad_login'] = "Falscher Benutzername oder Passwort";
$elang['invalid_username'] = "Der gewählte Benutzername ist nicht gültig";
$elang['username_exist'] = "Der gewählte Benutzername existiert bereits";
$elang['invalid_email'] = "Die gewählte E-Mail ist nicht gültig";
$elang['sel_age'] = "Bitte wähle dein Alter";
$elang['access_requirement'] = "Du erfüllst nicht die Anforderungen für den Zugang zu diesem Raum";
$elang['wrong_pass'] = "Passwort falsch";
$elang['room_full'] = "Dieser Raum ist voll, bitte versuche einen anderen";
$elang['friend_sent'] = "Deine Freundschaftsanfrage wurde gesendet";
$elang['new_friend'] = "Glückwunsch, du hast gerade einen neuen Freund gemacht";
$elang['empty_field'] = "Bitte fülle alle Felder aus";
$elang['room_name'] = "Ungültiger Raumname";
$elang['room_description'] = "Die Raumbeschreibung ist zu kurz";
$elang['invalid_pass'] = "Passwort muss zwischen 6 und 24 Zeichen lang sein";
$elang['room_exist'] = "Der gewählte Raumname existiert bereits";
$elang['max_room'] = "Du hast bereits dein Maximum an Räumen erreicht";
$elang['wrong_file'] = "Der ausgewählte Dateityp ist nicht erlaubt";
$elang['no_file'] = "Du musst eine Datei auswählen";
$elang['file_big'] = "Deine Datei ist zu groß";
$elang['too_short'] = "Suchkriterium ist zu kurz";
$elang['clean_complete'] = "Bereinigung abgeschlossen";
$elang['cant_modify_user'] = "Du hast keine Berechtigung, diesen Benutzer zu bearbeiten";
$elang['saved'] = "Gespeichert";
$elang['action_complete'] = "Aktion abgeschlossen";
$elang['email_sent'] = "E-Mail gesendet, bitte überprüfe deinen Posteingang";
$elang['room_block'] = "Du kannst den ausgewählten Raum derzeit nicht betreten";
$elang['bad_actual'] = "Das alte Passwort ist falsch";
$elang['not_match'] = "Die neuen Passwörter stimmen nicht überein";
$elang['recovery_sent'] = "Ein temporäres Passwort wurde an deine E-Mail gesendet";
$elang['no_user'] = "Kein Benutzer mit diesen Angaben gefunden";
$elang['something_wrong'] = "Etwas Ungewöhnliches wurde festgestellt, bitte warte, bis ein Administrator dein Konto prüft";
$elang['max_reg'] = "Du hast die maximal erlaubten Registrierungen erreicht, bitte versuche es später erneut";
$elang['select_something'] = "Bitte wähle etwas aus";
$elang['reported'] = "Vielen Dank für deinen Bericht";
$elang['already_erase'] = "Der Beitrag existiert nicht mehr";
$elang['already_reported'] = "Dieser Beitrag wurde bereits gemeldet";
$elang['ignored'] = "Benutzer wurde deiner Ignorieren-Liste hinzugefügt";
$elang['cannot_contact'] = "Du kannst diesen Benutzer momentan nicht kontaktieren";
$elang['new_message'] = "Neue Nachricht";
$elang['data_exist'] = "Die eingegebenen Daten existieren bereits";
$elang['register_close'] = "Wir nehmen momentan keine neuen Registrierungen entgegen, bitte versuche es später erneut";
$elang['site_connect'] = "Bitte verbinde dich mit der Seite, um den Chat zu betreten";
$elang['no_bridge'] = "An dem angegebenen Ort wurde keine Brücke erkannt";
$elang['invalid_code'] = "Falscher Code";
$elang['already_action'] = "Diese Aktion wurde bereits festgelegt";
$elang['missing_recaptcha'] = "Bitte vervollständige das reCAPTCHA";
$elang['no_result'] = "Keine Ergebnisse gefunden";
$elang['restricted_content'] = "Ein Teil der übermittelten Daten ist nicht erlaubt, bitte bearbeite ihn";
$elang['report_limit'] = "Du hast dein Berichtslimit erreicht";
$elang['vpn_usage'] = "Bitte schalte dein VPN/Proxy aus, um auf die Seite zuzugreifen";
$elang['coppa'] = "Du kannst die Seite derzeit nicht betreten";
$elang['age_requirement'] = "Du erfüllst nicht die Altersanforderung der Seite";
$elang['no_gold'] = "Du hast nicht genug Gold, um diese Transaktion abzuschließen";
$elang['invalid_data'] = "Ungültige Daten";
$elang['call_fail'] = "Mitglied ist momentan nicht verfügbar.";
$elang['low_balance'] = "Unzureichendes Guthaben.";
$elang['invalid_amount'] = "Ungültiger Betrag";
$elang['file_blocked'] = "Die Datei entspricht nicht unseren Richtlinien";
$elang['call_block'] = "Entschuldigung, du kannst diesem Anruf nicht beitreten";
$elang['act_limit'] = "Bitte warte, um diese Funktion erneut zu nutzen";
$elang['max_attempt'] = 'Zu viele fehlgeschlagene Versuche';
$elang['cannot_action'] = 'Du kannst diese Aktion nicht durchführen';

/* system message */ 

$slang['system__join'] = "%user% ist dem Raum beigetreten";
$slang['system__clear'] = "Dieser Raum wurde von %user% geleert";
$slang['system__name'] = "%custom% heißt jetzt %user%";
$slang['system__kick'] = "%user% wurde gekickt";
$slang['system__ban'] = "%user% wurde gesperrt";
$slang['system__mute'] = "%user% wurde stummgeschaltet";
$slang['system__block'] = "%user% wurde im Raum blockiert";

/* top notification */

$plang['user_join'] = "Ist verbunden";
?>