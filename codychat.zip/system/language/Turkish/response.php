<?php
$elang['invalid_command'] = "Bu komut mevcut değil";
$elang['email_exist'] = "Bu e-posta ile zaten bir hesap var";
$elang['error'] = "Bir hata oluştu";
$elang['updated'] = "Güncelleme tamamlandı";
$elang['cannot_user'] = "Belirtilen kullanıcı üzerinde bu işlemi gerçekleştiremezsin";
$elang['confirmed_command'] = "Komut başarıyla tamamlandı";
$elang['bad_login'] = "Kullanıcı adı veya şifre yanlış";
$elang['invalid_username'] = "Seçilen kullanıcı adı geçerli değil";
$elang['username_exist'] = "Seçilen kullanıcı adı zaten var";
$elang['invalid_email'] = "Seçilen e-posta geçerli değil";
$elang['sel_age'] = "Lütfen yaşınızı seçin";
$elang['access_requirement'] = "Bu odaya erişim için şartları karşılamıyorsunuz";
$elang['wrong_pass'] = "Şifre yanlış";
$elang['room_full'] = "Bu oda dolu, lütfen başka birini deneyin";
$elang['friend_sent'] = "Dostluk isteğiniz gönderildi";
$elang['new_friend'] = "Tebrikler, yeni bir arkadaş edindiniz";
$elang['empty_field'] = "Lütfen tüm alanları doldurun";
$elang['room_name'] = "Geçersiz oda adı";
$elang['room_description'] = "Oda açıklaması çok kısa";
$elang['invalid_pass'] = "Şifre 6 ile 24 karakter arasında olmalı";
$elang['room_exist'] = "Seçilen oda adı zaten mevcut";
$elang['max_room'] = "Maksimum oda sayınıza ulaştınız";
$elang['wrong_file'] = "Seçilen dosya türü izin verilen tür değil";
$elang['no_file'] = "Bir dosya seçmelisiniz";
$elang['file_big'] = "Dosyanız çok büyük";
$elang['too_short'] = "Arama kriteri çok kısa";
$elang['clean_complete'] = "Temizleme tamamlandı";
$elang['cant_modify_user'] = "Bu kullanıcıyı düzenleme izniniz yok";
$elang['saved'] = "Kaydedildi";
$elang['action_complete'] = "İşlem tamamlandı";
$elang['email_sent'] = "E-posta gönderildi, lütfen mailinizi kontrol edin";
$elang['room_block'] = "Seçilen odaya şu anda giremezsiniz";
$elang['bad_actual'] = "Eski şifre yanlış";
$elang['not_match'] = "Yeni şifreler eşleşmiyor";
$elang['recovery_sent'] = "Geçici bir şifre e-postanıza gönderildi";
$elang['no_user'] = "Bu bilgilerle kullanıcı bulunamadı";
$elang['something_wrong'] = "Alışılmadık bir durum algılandı, lütfen hesabınızın incelenmesini bekleyin";
$elang['max_reg'] = "Şu anda izin verilen maksimum kayıt sayısına ulaştınız, lütfen daha sonra tekrar deneyin";
$elang['select_something'] = "Lütfen bir şey seçin";
$elang['reported'] = "Bildirdiğiniz için teşekkürler";
$elang['already_erase'] = "Gönderi artık mevcut değil";
$elang['already_reported'] = "Bu gönderi zaten bildirildi";
$elang['ignored'] = "Kullanıcı engellenenler listenize eklendi";
$elang['cannot_contact'] = "Şu anda bu kullanıcıyla iletişim kuramazsınız";
$elang['new_message'] = "Yeni mesaj";
$elang['data_exist'] = "Girdiğiniz veri zaten mevcut";
$elang['register_close'] = "Şu anda yeni kayıt almıyoruz, lütfen daha sonra tekrar deneyin";
$elang['site_connect'] = "Sohbete giriş için siteye bağlanın lütfen";
$elang['no_bridge'] = "Belirtilen konumda köprü tespit edilemedi";
$elang['invalid_code'] = "Kod yanlış";
$elang['already_action'] = "Bu işlem zaten yapılmış";
$elang['missing_recaptcha'] = "Lütfen reCAPTCHA’yı tamamlayın";
$elang['no_result'] = "Sonuç bulunamadı";
$elang['restricted_content'] = "Gönderilen verilerde izin verilmeyen bir şey var, lütfen düzenleyin";
$elang['report_limit'] = "Bildirme limitinize ulaştınız";
$elang['vpn_usage'] = "Siteye girmek için VPN/proxy kapatın lütfen";
$elang['coppa'] = "Şu anda siteye giriş yapamazsınız";
$elang['age_requirement'] = "Sitenin yaş gereksinimini karşılamıyorsunuz";
$elang['no_gold'] = "Bu işlemi tamamlamak için yeterli altın yok";
$elang['invalid_data'] = "Geçersiz veri";
$elang['call_fail'] = "Üye şu anda müsait değil.";
$elang['low_balance'] = "Yetersiz bakiye.";
$elang['invalid_amount'] = "Geçersiz miktar";
$elang['file_blocked'] = "Dosya yönergelerimize uygun değil";
$elang['call_block'] = "Üzgünüm bu çağrıya giremezsiniz";
$elang['act_limit'] = "Bu özelliği tekrar kullanmak için lütfen bekleyin";
$elang['max_attempt'] = 'Çok fazla başarısız girişimi oldu';
$elang['cannot_action'] = 'Bu işlemi gerçekleştiremezsiniz';

/* system message */ 

$slang['system__join'] = "%user% odaya katıldı";
$slang['system__clear'] = "Bu oda %user% tarafından temizlendi";
$slang['system__name'] = "%custom% artık %user% olarak biliniyor";
$slang['system__kick'] = "%user% atıldı";
$slang['system__ban'] = "%user% yasaklandı";
$slang['system__mute'] = "%user% susturuldu";
$slang['system__block'] = "%user% oda engeli aldı";

/* top notification */

$plang['user_join'] = "Bağlandı";
?>