<?php
$elang['invalid_command'] = "That command does not exist";
$elang['email_exist'] = "An account already exists with that email";
$elang['error'] = "An error has occured";
$elang['updated'] = "Update completed";
$elang['cannot_user'] = "You cannot perform this action on the specified user";
$elang['confirmed_command'] = "Command successfully completed";
$elang['bad_login'] = "Incorrect username or password";
$elang['invalid_username'] = "Selected username is not valid";
$elang['username_exist'] = "Selected username already exists";
$elang['invalid_email'] = "Selected email is not valid";
$elang['sel_age'] = "Please select your age";
$elang['access_requirement'] = "You do not meet the requirements to access this room";
$elang['wrong_pass'] = "Password incorrect";
$elang['room_full'] = "This room is full, please try another one";
$elang['friend_sent'] = "Your friend request has been sent";
$elang['new_friend'] = "Congratulations, you just made a new friend";
$elang['empty_field'] = "Please fill out all fields";
$elang['room_name'] = "Invalid room name";
$elang['room_description'] = "Room description is too short";
$elang['invalid_pass'] = "Password must be between 6 and 24 characters";
$elang['room_exist'] = "Selected room name already exists";
$elang['max_room'] = "You have already reached your maximum number of rooms";
$elang['wrong_file'] = "Selected file type is not allowed";
$elang['no_file'] = "You must select a file";
$elang['file_big'] = "Your file is too large";
$elang['too_short'] = "Search critera is too short";
$elang['clean_complete'] = "Clean completed";
$elang['cant_modify_user'] = "You do not have permission to edit this user";
$elang['saved'] = "Saved";
$elang['action_complete'] = "Action completed";
$elang['email_sent'] = "Email sent, please check your email";
$elang['room_block'] = "You currently cannot enter selected room";
$elang['bad_actual'] = "Old password is incorrect";
$elang['not_match'] = "New passwords are not matching";
$elang['recovery_sent'] = "A temporary password has been sent to your email";
$elang['no_user'] = "No user was found with those details";
$elang['something_wrong'] = "Something unusual was detected, please wait for an administrator to review your account";
$elang['max_reg'] = "You have reached your maximum allowed registrations for now, please try again later";
$elang['select_something'] = "Please select something";
$elang['reported'] = "Thank you for reporting";
$elang['already_erase'] = "Post no longer exists";
$elang['already_reported'] = "This post has already been reported";
$elang['ignored'] = "User added to your ignore list";
$elang['cannot_contact'] = "You currently cannot contact this user";
$elang['new_message'] = "New message";
$elang['data_exist'] = "The data you inputted already exists";
$elang['register_close'] = "We are not currently accepting new registrations, please try again later";
$elang['site_connect'] = "Please connect to the site to enter chat";
$elang['no_bridge'] = "No bridge detected at your specified location";
$elang['invalid_code'] = "Incorrect code";
$elang['already_action'] = "This action has already been set";
$elang['missing_recaptcha'] = "Please complete the reCAPTCHA";
$elang['no_result'] = "No results found";
$elang['restricted_content'] = "Something in submitted data is not allowed, please edit it";
$elang['report_limit'] = "You have reached your report limit";
$elang['vpn_usage'] = "Please turn off your VPN/proxy to enter the site";
$elang['coppa'] = "You cannot enter the site at this time";
$elang['age_requirement'] = "You do not meet this site's age requirements";
$elang['no_gold'] = "Your do not have enough gold to complete this transaction";
$elang['invalid_data'] = "Invalid data";
$elang['call_fail'] = "Member is unavailable at the moment.";
$elang['low_balance'] = "Insuficient balance.";
$elang['invalid_amount'] = "Invalid amount";
$elang['file_blocked'] = "The file is not in accordance with our guidelines";
$elang['call_block'] = "Sorry you cannot enter this call";
$elang['act_limit'] = "Please wait to use that feature again";
$elang['max_attempt'] = 'Too many unsuccessful attempts';
$elang['cannot_action'] = 'You cannot perform this action';

/* system message */ 

$slang['system__join'] = "%user% has joined the room";
$slang['system__clear'] = "This room has been cleared by %user%";
$slang['system__name'] = "%custom% is now known as %user%";
$slang['system__kick'] = "%user% has been kicked";
$slang['system__ban'] = "%user% has been banned";
$slang['system__mute'] = "%user% has been muted";
$slang['system__block'] = "%user% has been room blocked";

/* top notification */

$plang['user_join'] = "Is connected";
?>