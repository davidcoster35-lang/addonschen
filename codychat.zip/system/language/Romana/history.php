<?php
$hlang['flood_mute'] = 'Flood linisteste';
$hlang['word_mute'] = 'Word linisteste';
$hlang['word_kick'] = 'Word da afara';
$hlang['spam_mute'] = 'Spam linisteste';
$hlang['spam_ghost'] = 'Spam ghost';
$hlang['spam_ban'] = 'Spam baneaza';
$hlang['mute'] = 'Linisteste';
$hlang['ban'] = 'Baneaza';
$hlang['kick'] = 'Da afara';
$hlang['flood_kick'] = 'Flood kick';
$hlang['vpn_kick'] = 'Vpn kick';
$hlang['main_mute'] = 'Main mute';
$hlang['private_mute'] = 'Private mute';
$hlang['ghost'] = 'Ghost';
$hlang['warn'] = 'Warning';
?>