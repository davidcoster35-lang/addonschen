<?php
$elang['invalid_command'] = "Această comandă nu există";
$elang['email_exist'] = "Există deja un cont cu acest email";
$elang['error'] = "A apărut o eroare";
$elang['updated'] = "Actualizare completă";
$elang['cannot_user'] = "Nu poți efectua această acțiune asupra utilizatorului specificat";
$elang['confirmed_command'] = "Comanda a fost executată cu succes";
$elang['bad_login'] = "Nume de utilizator sau parolă incorecte";
$elang['invalid_username'] = "Numele de utilizator selectat nu este valid";
$elang['username_exist'] = "Numele de utilizator selectat există deja";
$elang['invalid_email'] = "Email-ul selectat nu este valid";
$elang['sel_age'] = "Te rugăm să îți selectezi vârsta";
$elang['access_requirement'] = "Nu îndeplinești cerințele de acces pentru această cameră";
$elang['wrong_pass'] = "Parolă incorectă";
$elang['room_full'] = "Această cameră este plină, te rugăm să încerci alta";
$elang['friend_sent'] = "Cererea ta de prietenie a fost trimisă";
$elang['new_friend'] = "Felicitări, tocmai ai câștigat un prieten nou";
$elang['empty_field'] = "Te rugăm completează toate câmpurile";
$elang['room_name'] = "Nume invalid pentru cameră";
$elang['room_description'] = "Descrierea camerei este prea scurtă";
$elang['invalid_pass'] = "Parola trebuie să aibă între 6 și 24 caractere";
$elang['room_exist'] = "Numele camerei selectat există deja";
$elang['max_room'] = "Ai atins deja numărul maxim de camere";
$elang['wrong_file'] = "Tipul de fișier selectat nu este permis";
$elang['no_file'] = "Trebuie să selectezi un fișier";
$elang['file_big'] = "Fișierul tău este prea mare";
$elang['too_short'] = "Criteriul de căutare este prea scurt";
$elang['clean_complete'] = "Curățarea a fost finalizată";
$elang['cant_modify_user'] = "Nu ai permisiunea să editezi acest utilizator";
$elang['saved'] = "Salvat";
$elang['action_complete'] = "Acțiune finalizată";
$elang['email_sent'] = "Email trimis, te rugăm să îți verifici inbox-ul";
$elang['room_block'] = "Momentan nu poți intra în camera selectată";
$elang['bad_actual'] = "Parola veche este incorectă";
$elang['not_match'] = "Noile parole nu se potrivesc";
$elang['recovery_sent'] = "O parolă temporară a fost trimisă la email-ul tău";
$elang['no_user'] = "Nu a fost găsit niciun utilizator cu aceste date";
$elang['something_wrong'] = "A fost detectat ceva neobișnuit, așteaptă ca un administrator să îți revizuiască contul";
$elang['max_reg'] = "Ai atins numărul maxim de înregistrări permis acum, te rugăm încearcă mai târziu";
$elang['select_something'] = "Te rugăm să selectezi ceva";
$elang['reported'] = "Mulțumim pentru raportare";
$elang['already_erase'] = "Postarea nu mai există";
$elang['already_reported'] = "Această postare a fost deja raportată";
$elang['ignored'] = "Utilizatorul a fost adăugat la lista ta de ignorare";
$elang['cannot_contact'] = "În prezent nu poți contacta acest utilizator";
$elang['new_message'] = "Mesaj nou";
$elang['data_exist'] = "Datele pe care le-ai introdus există deja";
$elang['register_close'] = "Nu acceptăm înregistrări noi momentan, te rugăm încearcă mai târziu";
$elang['site_connect'] = "Te rugăm conectează-te la site pentru a intra în chat";
$elang['no_bridge'] = "Nu a fost detectat niciun pod la locația specificată";
$elang['invalid_code'] = "Cod incorect";
$elang['already_action'] = "Această acțiune a fost deja setată";
$elang['missing_recaptcha'] = "Te rugăm completează reCAPTCHA";
$elang['no_result'] = "Nu s-au găsit rezultate";
$elang['restricted_content'] = "Ceva din datele trimise nu este permis, te rugăm să îl editezi";
$elang['report_limit'] = "Ai atins limita de rapoarte";
$elang['vpn_usage'] = "Te rugăm dezactivează VPN-ul/proxy-ul pentru a accesa site-ul";
$elang['coppa'] = "Nu poți accesa site-ul în acest moment";
$elang['age_requirement'] = "Nu îndeplinești cerința de vârstă a site-ului";
$elang['no_gold'] = "Nu ai aur suficient pentru a finaliza această tranzacție";
$elang['invalid_data'] = "Date invalide";
$elang['call_fail'] = "Membrul nu este disponibil în acest moment.";
$elang['low_balance'] = "Sold insuficient.";
$elang['invalid_amount'] = "Sumă invalidă";
$elang['file_blocked'] = "Fișierul nu respectă ghidurile noastre";
$elang['call_block'] = "Ne pare rău, nu poți intra în această apelare";
$elang['act_limit'] = "Te rugăm așteaptă pentru a folosi din nou această funcție";
$elang['max_attempt'] = 'Prea multe încercări nereușite';
$elang['cannot_action'] = 'Nu poți efectua această acțiune';

/* system message */ 

$slang['system__join'] = "%user% s-a alăturat camerei";
$slang['system__clear'] = "Această cameră a fost ștearsă de %user%";
$slang['system__name'] = "%custom% este acum cunoscut ca %user%";
$slang['system__kick'] = "%user% a fost dat afară";
$slang['system__ban'] = "%user% a fost interzis";
$slang['system__mute'] = "%user% a fost redus la tăcere";
$slang['system__block'] = "%user% a fost blocat în cameră";

/* top notification */

$plang['user_join'] = "Este conectat";
?>