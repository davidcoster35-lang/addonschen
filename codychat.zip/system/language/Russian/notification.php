<?php
$nlang['like'] = 'Оценил Ваш пост';
$nlang['reply'] = 'Прокомментировал Ваш пост';
$nlang['add_post'] = 'Разместил что-то на стене';
$nlang['accept_friend'] = 'Принял ваш запрос на добавление в друзья';
$nlang['word_mute'] = 'Вы получили кляп на %delay% за мат';
$nlang['flood_mute'] = 'Вы получили кляп на %delay% за флуд';
$nlang['spam_mute'] = 'Вы получили кляп на %delay% за спам';
$nlang['rank_change'] = 'Ваш ранг был изменен на %rank%';
$nlang['mute'] = 'Вы получили кляп на %delay%';
$nlang['unmute'] = 'С Вас сняли кляп';
$nlang['name_change'] = 'Ваш ник был изменен на %data%';
$nlang['prolike'] = 'понравился ваш профиль';
$nlang['main_mute'] = 'Вы были отключены в основном чате на %delay%';
$nlang['private_mute'] = 'Вы были отключены в привате на %delay%';
$nlang['main_unmute'] = 'Ваш звук в основном чате включен';
$nlang['private_unmute'] = 'Ваш личный был включен';
$nlang['gold_share'] = 'Поделился %data% золото с тобой';
$nlang['gift'] = 'отправил вам подарок';
$nlang['vipgift'] = 'Отправил вам VIP-членство';
$nlang['vipsys'] = 'К вашему аккаунту добавлено VIP-членство';
$nlang['custom'] = '%custom%';
$nlang['mcall'] = 'Пропущенный вызов';
$nlang['ruby_share'] = 'поделился/поделилась с вами %data% рубинами';
$nlang['level'] = 'Отлично! Вы достигли уровня XP %data%';
$nlang['badge_ruby'] = 'Вы получили значок Рубиновый трейдер уровень %data%';
$nlang['badge_member'] = 'Вы получили значок Участник сообщества';
$nlang['badge_chat'] = 'Вы получили значок Активный участник уровень %data%';
$nlang['badge_auth'] = 'Вы получили значок Проверенный участник';
$nlang['badge_gift'] = 'Вы получили значок Хранитель подарков уровень %data%';
$nlang['badge_like'] = 'Вы получили значок Любимый участник уровень %data%';
$nlang['badge_friend'] = 'Вы получили значок Дружелюбный участник уровень %data%';
$nlang['badge_gold'] = 'Вы получили значок Золотой трейдер уровень %data%';
$nlang['badge_beat'] = 'Вы получили значок Преданный участник уровень %data%';
$nlang['badge_top'] = 'Вы получили значок Главный победитель уровень %data%';

?>