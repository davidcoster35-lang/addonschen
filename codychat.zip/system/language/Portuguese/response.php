<?php
$elang['invalid_command'] = "Esse comando não existe";
$elang['email_exist'] = "Já existe uma conta com esse email";
$elang['error'] = "Ocorreu um erro";
$elang['updated'] = "Atualização concluída";
$elang['cannot_user'] = "Não pode executar esta ação sobre o utilizador especificado";
$elang['confirmed_command'] = "Comando completado com sucesso";
$elang['bad_login'] = "Nome de utilizador ou palavra-passe incorretos";
$elang['invalid_username'] = "O nome de utilizador selecionado não é válido";
$elang['username_exist'] = "O nome de utilizador selecionado já existe";
$elang['invalid_email'] = "O email selecionado não é válido";
$elang['sel_age'] = "Por favor seleccione a sua idade";
$elang['access_requirement'] = "Não preenche os requisitos para aceder a esta sala";
$elang['wrong_pass'] = "Palavra-passe incorrecta";
$elang['room_full'] = "Esta sala está cheia, por favor tente outra";
$elang['friend_sent'] = "O seu pedido de amizade foi enviado";
$elang['new_friend'] = "Parabéns, acabou de ganhar um novo amigo";
$elang['empty_field'] = "Por favor preencha todos os campos";
$elang['room_name'] = "Nome da sala inválido";
$elang['room_description'] = "A descrição da sala é demasiado curta";
$elang['invalid_pass'] = "A palavra-passe deve ter entre 6 e 24 caracteres";
$elang['room_exist'] = "O nome da sala seleccionado já existe";
$elang['max_room'] = "Já atingiu o número máximo de salas";
$elang['wrong_file'] = "O tipo de ficheiro seleccionado não é permitido";
$elang['no_file'] = "Tem de seleccionar um ficheiro";
$elang['file_big'] = "O seu ficheiro é demasiado grande";
$elang['too_short'] = "O critério de pesquisa é demasiado curto";
$elang['clean_complete'] = "Limpeza concluída";
$elang['cant_modify_user'] = "Não tem permissão para editar este utilizador";
$elang['saved'] = "Gravado";
$elang['action_complete'] = "Acção completada";
$elang['email_sent'] = "Email enviado, por favor verifique o seu correio";
$elang['room_block'] = "Actualmente não pode entrar na sala seleccionada";
$elang['bad_actual'] = "A palavra-passe antiga está incorrecta";
$elang['not_match'] = "As novas palavras-passe não coincidem";
$elang['recovery_sent'] = "Foi enviada uma palavra-passe temporária para o seu email";
$elang['no_user'] = "Nenhum utilizador encontrado com esses dados";
$elang['something_wrong'] = "Detectámos algo invulgar, por favor aguarde que um administrador revê a sua conta";
$elang['max_reg'] = "Atingiu o número máximo de registos permitidos por agora, por favor tente mais tarde";
$elang['select_something'] = "Por favor seleccione algo";
$elang['reported'] = "Obrigado por reportar";
$elang['already_erase'] = "A publicação já não existe";
$elang['already_reported'] = "Essa publicação já foi reportada";
$elang['ignored'] = "Utilizador adicionado à sua lista de ignorados";
$elang['cannot_contact'] = "Actualmente não pode contactar este utilizador";
$elang['new_message'] = "Nova mensagem";
$elang['data_exist'] = "Os dados que inseriu já existem";
$elang['register_close'] = "Actualmente não estamos a aceitar novos registos, por favor tente mais tarde";
$elang['site_connect'] = "Por favor conecte-se ao site para entrar no chat";
$elang['no_bridge'] = "Nenhuma ponte detectada na localização especificada";
$elang['invalid_code'] = "Código incorrecto";
$elang['already_action'] = "Esta acção já foi definida";
$elang['missing_recaptcha'] = "Por favor complete o reCAPTCHA";
$elang['no_result'] = "Nenhum resultado encontrado";
$elang['restricted_content'] = "Algo nos dados submetidos não é permitido, por favor edite-o";
$elang['report_limit'] = "Atingiu o seu limite de reportes";
$elang['vpn_usage'] = "Por favor desactive o seu VPN/proxy para entrar no site";
$elang['coppa'] = "Actualmente não pode entrar no site";
$elang['age_requirement'] = "Não preenche os requisitos de idade do site";
$elang['no_gold'] = "Não tem ouro suficiente para completar esta transacção";
$elang['invalid_data'] = "Dados inválidos";
$elang['call_fail'] = "O membro não está disponível no momento.";
$elang['low_balance'] = "Saldo insuficiente.";
$elang['invalid_amount'] = "Montante inválido";
$elang['file_blocked'] = "O ficheiro não está de acordo com as nossas directrizes";
$elang['call_block'] = "Desculpe, não pode entrar nesta chamada";
$elang['act_limit'] = "Por favor aguarde para usar essa funcionalidade novamente";
$elang['max_attempt'] = 'Muitas tentativas falhadas';
$elang['cannot_action'] = 'Não pode realizar esta acção';

/* system message */ 

$slang['system__join'] = "%user% entrou na sala";
$slang['system__clear'] = "Esta sala foi limpa por %user%";
$slang['system__name'] = "%custom% agora é conhecido como %user%";
$slang['system__kick'] = "%user% foi expulso";
$slang['system__ban'] = "%user% foi banido";
$slang['system__mute'] = "%user% foi silenciado";
$slang['system__block'] = "%user% foi bloqueado na sala";

/* top notification */

$plang['user_join'] = "Está conectado";
?>