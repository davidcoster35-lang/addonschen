<?php
$elang['invalid_command'] = "Cette commande n’existe pas";
$elang['email_exist'] = "Un compte existe déjà avec cet email";
$elang['error'] = "Une erreur est survenue";
$elang['updated'] = "Mise à jour terminée";
$elang['cannot_user'] = "Vous ne pouvez pas effectuer cette action sur l’utilisateur spécifié";
$elang['confirmed_command'] = "Commande exécutée avec succès";
$elang['bad_login'] = "Nom d’utilisateur ou mot de passe incorrect";
$elang['invalid_username'] = "Le nom d’utilisateur sélectionné n’est pas valide";
$elang['username_exist'] = "Le nom d’utilisateur sélectionné existe déjà";
$elang['invalid_email'] = "L’email sélectionné n’est pas valide";
$elang['sel_age'] = "Veuillez sélectionner votre âge";
$elang['access_requirement'] = "Vous ne remplissez pas les conditions d’accès à cette salle";
$elang['wrong_pass'] = "Mot de passe incorrect";
$elang['room_full'] = "Cette salle est complète, veuillez en essayer une autre";
$elang['friend_sent'] = "Votre demande d’ami a été envoyée";
$elang['new_friend'] = "Félicitations, vous venez de vous faire un nouvel ami";
$elang['empty_field'] = "Veuillez remplir tous les champs";
$elang['room_name'] = "Nom de salle invalide";
$elang['room_description'] = "La description de la salle est trop courte";
$elang['invalid_pass'] = "Le mot de passe doit comporter entre 6 et 24 caractères";
$elang['room_exist'] = "Le nom de salle sélectionné existe déjà";
$elang['max_room'] = "Vous avez déjà atteint votre nombre maximal de salles";
$elang['wrong_file'] = "Le type de fichier sélectionné n’est pas autorisé";
$elang['no_file'] = "Vous devez sélectionner un fichier";
$elang['file_big'] = "Votre fichier est trop volumineux";
$elang['too_short'] = "Le critère de recherche est trop court";
$elang['clean_complete'] = "Nettoyage terminé";
$elang['cant_modify_user'] = "Vous n’avez pas la permission de modifier cet utilisateur";
$elang['saved'] = "Enregistré";
$elang['action_complete'] = "Action terminée";
$elang['email_sent'] = "Email envoyé, veuillez vérifier votre boîte mail";
$elang['room_block'] = "Vous ne pouvez pas actuellement entrer dans la salle sélectionnée";
$elang['bad_actual'] = "L’ancien mot de passe est incorrect";
$elang['not_match'] = "Les nouveaux mots de passe ne correspondent pas";
$elang['recovery_sent'] = "Un mot de passe temporaire a été envoyé à votre e-mail";
$elang['no_user'] = "Aucun utilisateur trouvé avec ces informations";
$elang['something_wrong'] = "Quelque chose d’inhabituel a été détecté, veuillez attendre qu’un administrateur examine votre compte";
$elang['max_reg'] = "Vous avez atteint le nombre maximal d’inscriptions autorisées pour le moment, veuillez réessayer plus tard";
$elang['select_something'] = "Veuillez sélectionner quelque chose";
$elang['reported'] = "Merci pour votre signalement";
$elang['already_erase'] = "Le post n’existe plus";
$elang['already_reported'] = "Ce post a déjà été signalé";
$elang['ignored'] = "Utilisateur ajouté à votre liste d’ignorés";
$elang['cannot_contact'] = "Vous ne pouvez actuellement pas contacter cet utilisateur";
$elang['new_message'] = "Nouveau message";
$elang['data_exist'] = "Les données que vous avez saisies existent déjà";
$elang['register_close'] = "Nous n’acceptons pas actuellement de nouvelles inscriptions, veuillez réessayer plus tard";
$elang['site_connect'] = "Veuillez vous connecter au site pour entrer dans le chat";
$elang['no_bridge'] = "Aucun pont détecté à l’emplacement spécifié";
$elang['invalid_code'] = "Code incorrect";
$elang['already_action'] = "Cette action a déjà été définie";
$elang['missing_recaptcha'] = "Veuillez compléter le reCAPTCHA";
$elang['no_result'] = "Aucun résultat trouvé";
$elang['restricted_content'] = "Quelque chose dans les données soumises n’est pas autorisé, veuillez le modifier";
$elang['report_limit'] = "Vous avez atteint votre limite de signalements";
$elang['vpn_usage'] = "Veuillez désactiver votre VPN/proxy pour accéder au site";
$elang['coppa'] = "Vous ne pouvez pas entrer sur le site pour le moment";
$elang['age_requirement'] = "Vous ne remplissez pas les exigences d’âge du site";
$elang['no_gold'] = "Vous n’avez pas assez d’or pour effectuer cette transaction";
$elang['invalid_data'] = "Données invalides";
$elang['call_fail'] = "Le membre n’est pas disponible pour le moment.";
$elang['low_balance'] = "Solde insuffisant.";
$elang['invalid_amount'] = "Montant invalide";
$elang['file_blocked'] = "Le fichier n’est pas conforme à nos directives";
$elang['call_block'] = "Désolé, vous ne pouvez pas rejoindre cet appel";
$elang['act_limit'] = "Veuillez attendre pour utiliser à nouveau cette fonctionnalité";
$elang['max_attempt'] = 'Trop de tentatives infructueuses';
$elang['cannot_action'] = 'Vous ne pouvez pas effectuer cette action';

/* system message */ 

$slang['system__join'] = "%user% a rejoint le salon";
$slang['system__clear'] = "Ce salon a été effacer par %user%";
$slang['system__name'] = "%custom% a changé de nom pour %user%";
$slang['system__kick'] = "%user% a été kické";
$slang['system__ban'] = "%user% a été banni";
$slang['system__mute'] = "%user% a été mis en silence";
$slang['system__block'] = "%user% a été bloqué de ce salon";

/* top notification */

$plang['user_join'] = "Est en ligne";
?>