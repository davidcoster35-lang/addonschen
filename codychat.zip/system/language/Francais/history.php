<?php
$hlang['flood_mute'] = 'Silence flood';
$hlang['word_mute'] = 'Silence language';
$hlang['word_kick'] = 'Kick language';
$hlang['spam_mute'] = 'Silence spam';
$hlang['spam_ghost'] = 'Spam ghost';
$hlang['spam_ban'] = 'Ban spam';
$hlang['mute'] = 'Silence';
$hlang['ban'] = 'Ban';
$hlang['kick'] = 'Kick';
$hlang['flood_kick'] = 'Flood kick';
$hlang['vpn_kick'] = 'Vpn kick';
$hlang['main_mute'] = 'Silence chat';
$hlang['private_mute'] = 'Silence privé';
$hlang['ghost'] = 'Ghost';
$hlang['warn'] = 'Avertissement';
?>