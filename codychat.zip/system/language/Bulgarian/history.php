<?php
$hlang['flood_mute'] = 'Заглушен/а заради спам';
$hlang['word_mute'] = 'Заглушен/а заради лоши думи';
$hlang['word_kick'] = 'Изритан/а заради лоши думи';
$hlang['spam_mute'] = 'Заглуши заради спам';
$hlang['spam_ghost'] = 'Φάντασμα spam';
$hlang['spam_ban'] = 'Бан за спам';
$hlang['mute'] = 'Заглуши';
$hlang['ban'] = 'Бан';
$hlang['kick'] = 'Изритай';
$hlang['flood_kick'] = 'Πλημμύρα';
$hlang['vpn_kick'] = 'Κλωτσιά Vpn';
$hlang['main_mute'] = 'Κύριο μουγγό';
$hlang['private_mute'] = 'Ιδιωτικό μουγγό';
$hlang['ghost'] = 'Φάντασμα';
$hlang['warn'] = 'Warning';
?>