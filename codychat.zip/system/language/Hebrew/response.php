<?php
$elang['invalid_command'] = "הפקודה הזו לא קיימת";
$elang['email_exist'] = "קיים כבר חשבון עם האימייל הזה";
$elang['error'] = "אירעה שגיאה";
$elang['updated'] = "העדכון הושלם";
$elang['cannot_user'] = "אין באפשרותך לבצע פעולה זו על המשתמש שצוין";
$elang['confirmed_command'] = "הפקודה בוצעה בהצלחה";
$elang['bad_login'] = "שם המשתמש או הסיסמה אינם נכונים";
$elang['invalid_username'] = "שם המשתמש שנבחר אינו חוקי";
$elang['username_exist'] = "שם המשתמש שנבחר כבר קיים";
$elang['invalid_email'] = "האימייל שנבחר אינו חוקי";
$elang['sel_age'] = "אנא בחר/י את גילך";
$elang['access_requirement'] = "אינך עומד/ת בדרישות הכניסה לחדר זה";
$elang['wrong_pass'] = "הסיסמה שגויה";
$elang['room_full'] = "החדר מלא, אנא נסה/י חדר אחר";
$elang['friend_sent'] = "בקשת החברות שלך נשלחה";
$elang['new_friend'] = "מזל טוב, הרווחת חבר חדש";
$elang['empty_field'] = "אנא מלא/י את כל השדות";
$elang['room_name'] = "שם החדר אינו חוקי";
$elang['room_description'] = "תיאור החדר קצר מדי";
$elang['invalid_pass'] = "הסיסמה חייבת להיות בין 6 ל-24 תווים";
$elang['room_exist'] = "שם החדר שנבחר כבר קיים";
$elang['max_room'] = "הגעת/ה למספר החדרים המקסימלי שלך";
$elang['wrong_file'] = "סוג הקובץ שנבחר אינו מורשה";
$elang['no_file'] = "עליך לבחור קובץ";
$elang['file_big'] = "הקובץ שלך גדול מדי";
$elang['too_short'] = "קריטריון החיפוש קצר מדי";
$elang['clean_complete'] = "ניקוי הושלם";
$elang['cant_modify_user'] = "אין לך הרשאה לערוך משתמש זה";
$elang['saved'] = "נשמר";
$elang['action_complete'] = "הפעולה הושלמה";
$elang['email_sent'] = "אימייל נשלח, אנא בדוק/י את תיבת הדואר שלך";
$elang['room_block'] = "כרגע אין באפשרותך להיכנס לחדר הנבחר";
$elang['bad_actual'] = "הסיסמה הישנה שגויה";
$elang['not_match'] = "הסיסמאות החדשות לא תואמות";
$elang['recovery_sent'] = "נשלחה סיסמה זמנית למייל שלך";
$elang['no_user'] = "לא נמצא משתמש עם הפרטים הללו";
$elang['something_wrong'] = "נמצא משהו לא רגיל, אנא המתן/י למנהל שיבדוק את החשבון שלך";
$elang['max_reg'] = "הגעת/ה למספר ההרשמות המרבי המותר לעת עתה, אנא נסה/י שוב מאוחר יותר";
$elang['select_something'] = "אנא בחר/י משהו";
$elang['reported'] = "תודה על הדיווח";
$elang['already_erase'] = "הפרסום כבר לא קיים";
$elang['already_reported'] = "הפרסום כבר נבדק";
$elang['ignored'] = "המשתמש נוסף לרשימת ההתעלמות שלך";
$elang['cannot_contact'] = "כרגע אין באפשרותך לפנות למשתמש זה";
$elang['new_message'] = "הודעה חדשה";
$elang['data_exist'] = "הנתונים שהזנת כבר קיימים";
$elang['register_close'] = "כרגע אין קבלת הרשמות חדשות, אנא נסה/י שוב מאוחר יותר";
$elang['site_connect'] = "אנא התחבר/י לאתר כדי להיכנס לצ’אט";
$elang['no_bridge'] = "לא נמצא גשר במקום שצוין";
$elang['invalid_code'] = "קוד שגוי";
$elang['already_action'] = "הפעולה כבר הוגדרה";
$elang['missing_recaptcha'] = "אנא השלם/י את ה-reCAPTCHA";
$elang['no_result'] = "לא נמצאו תוצאות";
$elang['restricted_content'] = "משהו בנתונים שנשלחו אינו מותר, אנא ערוך/י אותם";
$elang['report_limit'] = "הגעת/ה למגבלת הדיווחים שלך";
$elang['vpn_usage'] = "אנא כבה/י את ה-VPN/פרוקסי כדי להיכנס לאתר";
$elang['coppa'] = "אין באפשרותך להיכנס לאתר כעת";
$elang['age_requirement'] = "אינך עומד/ת בדרישת הגיל של האתר";
$elang['no_gold'] = "אין לך מספיק זהב לביצוע העסקה";
$elang['invalid_data'] = "נתונים לא חוקיים";
$elang['call_fail'] = "החבר אינו זמין כרגע.";
$elang['low_balance'] = "יתרה לא מספיקה.";
$elang['invalid_amount'] = "סכום לא חוקי";
$elang['file_blocked'] = "הקובץ אינו עומד בהנחיות שלנו";
$elang['call_block'] = "מצטערים, אינך יכול/ה להצטרף לשיחה זו";
$elang['act_limit'] = "אנא המתין/י לפני שתשתמש/י בשירות שוב";
$elang['max_attempt'] = 'יותר מדי ניסיונות שנכשלו';
$elang['cannot_action'] = 'אינך יכול/ה לבצע את הפעולה הזו';

/* system message */ 

$slang['system__join'] = "%user% הצטרף לחדר";
$slang['system__clear'] = "החדר נוקה על ידי %user%";
$slang['system__name'] = "%custom% נקרא עכשיו %user%";
$slang['system__kick'] = "%user% סולק";
$slang['system__ban'] = "%user% נחסם";
$slang['system__mute'] = "%user% הושתק";
$slang['system__block'] = "%user% נחסם מהחדר";

/* top notification */

$plang['user_join'] = "מחובר";
?>